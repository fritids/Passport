<fieldset class="signup-school-row">
	<input type="text" class="signup-school-name" placeholder="Enter Full School Name" />
	<label class="inline-label">Starting Year</label>
	<input type="number" class="signup-school-year-start" placeholder="1996" min="1950" max="2030"/>
	<label class="inline-label">Ending Year</label>
	<input type="number" class="signup-school-year-end"  placeholder="2002" min="1950" max="2030"/>
</fieldset>

<fieldset class="signup-school-row hidden blank-row">
	<input type="text" class="signup-school-name" placeholder="Enter Full School Name" />
	<label class="inline-label">Starting Year</label>
	<input type="number" class="signup-school-year-start" placeholder="2002"  min="1950" max="2030"/>
	<label class="inline-label">Ending Year</label>
	<input type="number" class="signup-school-year-end" placeholder="2006" min="1950" max="2030"/>
</fieldset>